import { Sequelize } from "sequelize";

// SQL_USERNAME = 'root'
// SQL_DATABASE = 'sys'
// SQL_PASSWORD = 'ashugola'
// SQL_HOST = 'localhost'

export const dbCredentials = {
    user: process.env.SQL_USERNAME,
    password: process.env.SQL_PASSWORD,
    database: process.env.SQL_DATABASE,
    host: process.env.SQL_HOST,
};


export const sequelize = new Sequelize(
  process.env.SQL_DATABASE,
  process.env.SQL_USERNAME,
  process.env.SQL_PASSWORD,
  {
    host: process.env.SQL_HOST,
    dialect: "mysql",
  }
);
