import { userRoutes } from "./userRoutes.js";

export let allRoutes = (server) => {
  server.use("/user", userRoutes);
};
