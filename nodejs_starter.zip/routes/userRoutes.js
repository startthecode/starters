import express from "express";

let routes = express.Router();

export let userRoutes = routes.get("/users", (req, res) => {
  res.send("hellow");
});
