import "dotenv/config";
import express from "express";
import cors from "cors";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import session from "express-session";
import { allRoutes } from "./routes/allRoutes.js";
import MySQLStore from "express-mysql-session";
import MySQLStoreImport from "express-mysql-session";
import { dbCredentials } from "./database/initializeDB.js";
let server = express();


// initalize Cors
server.use(
  cors({
    origin: process.env.CLIENT_URL,
    credentials: true,
    optionSuccessStatus: 204,
  })
);

// database init
let mysqlStore = MySQLStoreImport(session);
const sessionStore = new mysqlStore(dbCredentials);
server.use(
  session({
    key: "session_cookie_name",
    secret: "session_cookie_secret",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
  })
);

// static File path
let __filename = fileURLToPath(import.meta.url);
let __dirname = dirname(__filename);
server.use(express.static(join(__dirname, "/")));

// get body data
server.use(express.json());
server.use(express.urlencoded({ extended: true }));

//initialize all routes
allRoutes(server);

// init server
server.listen(process.env.SERVE_PORT, () => {
  console.log(`server listening on port ${process.env.SERVE_PORT}`);
});
