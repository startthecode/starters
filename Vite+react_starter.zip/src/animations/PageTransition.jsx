import { motion } from "framer-motion";
export const PageTransition = (OgComponent) => {
  let slideIN = {
    className: "fixed top-0 left-0 origin-left h-[100svh] w-full bg-black z-50",
    animate: { scaleX: 0 },
    initial: { scaleX: 0 },
    exit: { scaleX: 1 },
    transition: { duration: 1, ease: "linear" },
  };

  let slideOUT = {
    className:
      "fixed top-0 left-0 origin-bottom h-[100svh] w-full bg-black z-50",
    animate: { scaleY: 0 },
    initial: { scaleY: 1 },
    exit: { scaleY: 0 },
    transition: { duration: 1, ease: "linear" },
  };

  return () => (
    <>
      <OgComponent />
      <motion.div {...slideIN} />
      <motion.div {...slideOUT} />
    </>
  );
};
