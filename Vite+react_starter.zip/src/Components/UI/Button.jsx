export const Button = ({ text, url, size, extraclasses, ...props }) => {
  if (url)
    <a href={url} className={`btn ${size}`}>
      {text}
    </a>;

  return (
    <button className={`${extraclasses} btn ${size}`} {...props}>
      {text}
    </button>
  );
};
