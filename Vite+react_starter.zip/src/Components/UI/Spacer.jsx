export const Spacer = ({ rem }) => {
  return <div className={`spacer py-[${rem}]`}></div>;
};
