import { Routes, Route, useLocation } from "react-router-dom";
import { AppLayout } from "../Components/layout/AppLayout";
import { Home, About } from "../pages/AllPageExport";
import { motion, AnimatePresence } from "framer-motion"
export const AllRoutes = () => {
  let location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location?.pathname}>
        <Route path="" element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" />
          <Route path="/work" />
        </Route>
      </Routes>
    </AnimatePresence>
  );
};
