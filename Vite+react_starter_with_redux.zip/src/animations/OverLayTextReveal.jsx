import React, { useEffect, useRef } from "react";
import { gsap } from "../plugins/gsapSetup";


export const OverlayTextReveal = ({
  children,
  revealingSide,
  onlyoverlay,
  starting,
  ending,
}) => {
  let ref = useRef();
  let revealside =
    revealingSide === "right" ? "translate-x-[200px]" : "translate-x-[-200px]";
  useEffect(() => {
    //// text reveal
    let text = ref.current;
    let textReveal = gsap.timeline({
      scrollTrigger: {
        trigger: text,
        start: starting || "center bottom",
        end: ending || `bottom center`,
        scrub: 2,
      },
    });

    textReveal
      .to(text, {
        translateX: "0px",
        duration: 4,
        ease: "power1.out",
      })
      .to(
        text.querySelector(".overlay"),
        {
          width: 0,
          duration: 3,
          ease: "linear",
        },
        0.5
      );
  }, []);
  return (
    <div
      ref={ref}
      className={`textReveal relative max-w-max ${!onlyoverlay && revealside}`}
    >
      <div className="bg-[#fcfcfc63] absolute left-0 top-0 w-full h-full overlay"></div>
      {children}
    </div>
  );
};
