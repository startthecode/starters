import { createSlice } from "@reduxjs/toolkit";

let userIntialState = {
  userID: 45656,
  userName: "xyz",
};

const createUserSlice = createSlice({
  name: "UserInfo",
  initialState: userIntialState,
  reducers: {
    updateUserDtl(state, action) {
      const { userID } = action.payload ?? {};
      let updatedData = { ...state, userID };
      return updatedData;
    },
  },
});

export let { updateUserDtl } = createUserSlice.actions;
export let userSlice = createUserSlice.reducer;
