import { configureStore } from "@reduxjs/toolkit";
import { userSlice } from "./userSlice";
export let store = configureStore({
  reducer: {
    userInfo: userSlice,
  },
});

//export redux store info
export let getUserInfo = (state) => state.userInfo;
