import React from "react";
import { useEffect, useRef } from "react";
import { gsap } from "../../plugins/gsapSetup";
import { ReactLenis } from "@studio-freight/react-lenis";
const SmoothScrolling = ({ children, ...props }) => {
  let defaultOptions = {
    options: { duration: 1.9 },
    root: true,
    ...props,
  };
  const lenisRef = useRef();
  useEffect(() => {
    function update(time) {
      lenisRef.current?.lenis?.raf(time * 1000);
    }

    gsap.ticker.add(update);

    return () => {
      gsap.ticker.remove(update);
    };
  });

  return <ReactLenis {...defaultOptions}>{children}</ReactLenis>;
};

export default SmoothScrolling;
