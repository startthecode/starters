export const Input = ({
  placeholder,
  text,
  size,
  extraclasses,
  type = "text",
  ...props
}) => {
  if (type === "checkbox" || type === "radio")
    return <input type={type} className={`input_checkbox ${extraclasses}`} />;

  return (
    <>
      <input type={type} className={`input ${extraclasses}`} />
    </>
  );
};
