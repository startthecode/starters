import { Outlet } from "react-router-dom";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { useEffect, useRef } from "react";
import { gsap } from "../../plugins/gsapSetup";
import { ReactLenis } from "@studio-freight/react-lenis";
import SmoothScrolling from "../UI/SmoothScrolling";

export const AppLayout = () => {
  

  return (
    <div>
      <SmoothScrolling options={{ duration: 2 }} root />
      <Header />
      <Outlet />
      <Footer />
    </div>
  );
};
