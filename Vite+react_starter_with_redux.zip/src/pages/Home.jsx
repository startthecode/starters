import { OverlayTextReveal } from "../animations/OverLayTextReveal";
import { PageTransition } from "../animations/PageTransition";

export const Home = PageTransition(() => {
  return <></>;
});
