import { PageTransition } from "../animations/PageTransition";

export const About = PageTransition(() => {
  return <div>About</div>;
});
