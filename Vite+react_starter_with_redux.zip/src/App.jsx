import { BrowserRouter } from "react-router-dom";
import { Button } from "./Components/UI/Button";
import { Input } from "./Components/UI/Input";
import "./assets/scss/site.scss";
import { AllRoutes } from "./routes/AllRoutes";
import { Provider } from "react-redux";
import { store } from "./redux/store";
function App() {
  return (
    <>
      <Provider store={store}>
        <BrowserRouter>
          <AllRoutes />
        </BrowserRouter>
      </Provider>
    </>
  );
}

export default App;
