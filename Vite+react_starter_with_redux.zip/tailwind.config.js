/** @type {import('tailwindcss').Config} */
const defaultTheme = require("tailwindcss/defaultTheme");
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      container: {
        center: true,
        padding: "15px",
      },
      borderWidth: {
        1: "1px",
      },
      colors: {
        // theme colors
        theme_primary_clr: "#ED2A01",
        theme_secondary_clr: "#CB8922",
        theme_tertiary_clr: "#22CB74",

        // theme heading colors
        heading_primary_clr: "#2271CB",
        heading_secondary_clr: "#9322CB",
        heading_tertiary_clr: "#CB2234",

        // theme peragraph colors
        text_primary_clr: "#fff",
        text_secondary_clr: "#70EE13",
        text_tertiary_clr: "#040119",

        // theme border colors
        border_primary_clr: "#D4EE13",
        border_secondary_clr: "#70EE13",
        border_tertiary_clr: "#040119",

        // theme inputs colors
        input_primary_clr: "#fff",
        input_secondary_clr: "#fff",
        input_tertiary_clr: "#fff",
      },
      margin: {
        section_margin_lg: "100px",
        section_margin_md: "80px",
        section_margin_sm: "60px",
        section_margin_xs: "40px",
      },
      padding: {
        section_padding_lg: "100px",
        section_padding_md: "80px",
        section_padding_sm: "60px",
        section_padding_xs: "40px",
      },
      fontFamily: {
        primary_font: ['"Poppins"', ...defaultTheme.fontFamily.sans],
      },
    },
  },
  plugins: [],
};
